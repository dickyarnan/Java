import java.util.Scanner;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.lang.Math;
import java.util.Random;

/**
 * Class which stores information of AFLGame
 *
 * @author Dicky Arnan
 * @version ver1.0.0
 */
public class AFLGame
{   
    private Team teamA;
    private Team teamB;
    private Team prevTeamPossession;
    private Team teamPossession;
    private static RandomNumberGenerator random = new RandomNumberGenerator();
    private static final int BEHIND = 1;
    private static final int GOAL = 6;
    private static final int QUARTER = 4;
    private static final int DURATION = 20;
    private static final int EVENT = 80;

    /**
     * Default constructor which creates the object of the class AFLGame.
     *
     */ 
    public AFLGame()
    {
        teamA = new Team();
        teamB = new Team();
        teamPossession = null;
        prevTeamPossession = null;
    }

    /**
     * Non-Default constructor which creates the object of the class AFLGame.
     *
     * @param newTeamA    Accepts one team to be set as Team A as a Team.
     * @param newTeamB    Accepts one team to be set as Team B as a Team.
     */
    public AFLGame(Team newTeamA, Team newTeamB)
    {
        teamA = newTeamA;
        teamB = newTeamB;
        teamPossession = null;
        prevTeamPossession = null;
    }

    /**
     * A method to continue the game after other team scored a behind.
     *
     */
    public void continueGame()
    {
        swapTeam();
        teamPossession.choosePossession("Defender");
        System.out.printf(" picked up the ball in the defensive half.\n");
    }

    /**
     * Display method to display the result of the game.
     *
     */
    public void display()
    {
        Display objDisplay = new Display();
        objDisplay.displayGameResult(teamA, teamB);
        objDisplay.displayStatistic(teamA);
        objDisplay.displayStatistic(teamB);
        objDisplay.displayInjured(teamA, teamB);
        objDisplay.displayReported(teamA, teamB);
    }

    /**
     * A method to show the end of the game.
     *
     */
    public void endGame()
    {
        display();
    }

    /**
     * A method to forfeit the game when one team has no more reserve players.
     *
     */
    public void forfeitGame()
    {
        Team winningTeam = new Team();
        if(teamA.getInjuryCount() > teamA.getReserveCount())
        {
            winningTeam = teamB;
        }
        else if(teamB.getInjuryCount() > teamB.getReserveCount())
        {
            winningTeam = teamA;
        }
        System.out.printf("\n%s won the game!\n", winningTeam.getTeamName());
    }
    
    /**
     * A method to randomly select a player to be set as injured on each event.
     *
     */
    public void getInjured()
    {
        String redCircle = "\u001B[31m\u25CF\u001B[0m";
        String position = "";
        Team injuredTeam = teamPossession;
        int anIndex = random.giveRandomInt(0,2);
        if (anIndex == 1)
        {
            injuredTeam = prevTeamPossession;
        }

        int injuryChance = 2;
        int chance = random.giveRandomInt();
        
        if (chance > 0 && chance <= injuryChance)
        {
            if(teamPossession.equals(prevTeamPossession))
            {
                position = injuredTeam.selectInjuredPlayer();
            }
            else if(!teamPossession.equals(prevTeamPossession))
            {
                position = injuredTeam.getInjuredPlayer();
            }

            injuredTeam.addInjuryCount();
            
            System.out.printf(" got injured. %s\n", redCircle);
            if (injuredTeam.getInjuryCount() > injuredTeam.getReserveCount())
            {
                System.out.printf("%s has no more reserve players.\n", injuredTeam.getTeamName());
                forfeitGame();
            }
            else
            {
                substitutePlayer(injuredTeam, position);
            }   
        }
    }

    /**
     * Accessor method to get Team A.
     *
     * @return              Team A as a Team.
     */
    public Team getTeamA()
    {
        return teamA;
    }

    /**
     * Accessor method to get Team B.
     *
     * @return              Team B as a Team.
     */
    public Team getTeamB()
    {
        return teamB;
    }

    /**
     * Accessor method to get the Team Possession.
     *
     * @return              The Team Possession as a Team.
     */
    public Team getTeamPossession()
    {
        return teamPossession;
    }

    /**
     * Accessor method to get the Previous Team Possession.
     *
     * @return              The Previous Team Possession as a Team.
     */
    public Team getPrevTeamPossession()
    {
        return prevTeamPossession;
    }

    /**
     * A method to handle kickoff event of the game.
     *
     */
    public void kickOff()
    {
        System.out.printf("Starting from the centre circle.\n");
        int chance = random.giveRandomInt();
        int chanceA = 50;
        int chanceB = 100;

        if (chance > 0 && chance <= chanceA)
        {
            teamPossession = teamA;
        }
        else if (chance > chanceA && chance <= chanceB)
        {
            teamPossession = teamB;
        }
        teamPossession.choosePossession("Midfielder");
        System.out.printf(" got the ball in the centre circle.\n");
    }

    /**
     * Method to being the program.
     *
     * @param args          An array of Strings representing command line arguments.
     */
    public static void main(String[] args)
    {
        AFLGame objAflGame = new AFLGame();
        objAflGame.startGame();
    }

    /**
     * A method to pass the ball to a Forward player.
     *
     */
    public void passToForward()
    {
        System.out.printf(" passed the ball to ");
        teamPossession.choosePossession("Forward");
        System.out.printf(".\n");
        teamPossession.displayPossession();
        System.out.printf(" has the ball in the offensive half.\n");
    }

    /**
     * A method to pass the ball to a Midfielder player.
     *
     */
    public void passToMidfield()
    {
        System.out.printf(" passed the ball to ");
        teamPossession.choosePossession("Midfielder");
        System.out.printf(".\n");
        teamPossession.displayPossession();
        System.out.printf(" has the ball in the middle field.\n");
    }

    /**
     * A method to randomly select a player to be reported.
     *
     */
    public void reportPlayer()
    {   
        String yellowCircle = "\u001B[33m\u25CF\u001B[0m";
        int teamChance = random.giveRandomInt();
        int chanceA = 50;
        int chanceB = 100;
        Team reportedTeam = new Team();

        if (teamChance > 0 && teamChance <= chanceA)
        {
            reportedTeam = teamA;
        }
        else if (teamChance > chanceA && teamChance <= chanceB)
        {
            reportedTeam = teamB;
        }

        int reportChance = 1;
        int chance = random.giveRandomInt();
        if (chance > 0 && chance <= reportChance)
        {
            reportedTeam.chooseReported();
            System.out.printf(" got reported by the umpire. %s\n", yellowCircle);
        }
    }

    /**
     * A method to add the team's score when scoring a behind.
     *
     */
    public void scoreBehind()
    {
        teamPossession.addTeamScore(BEHIND);
        System.out.printf(" scored a behind! Got %d point!\n", BEHIND);
    }

    /**
     * A method to add the team's score when scoring a goal.
     *
     */
    public void scoreGoal()
    {
        teamPossession.addTeamScore(GOAL);
        System.out.printf(" scored a goal! Got %d points!\n", GOAL);
    }

    /**
     * A method to set the team's star players.
     *
     * @param team  A team that will have star players as a Team.
     */
    public void setStar(Team team)
    {
        Input objInput = new Input();
        Validation objValidation = new Validation();
        String userInput = "";
        boolean isValidInput = false;

        while (!isValidInput)
        {
            userInput = objInput.acceptStringInput("Enter number of star players in " 
                                                            + team.getTeamName() 
                                                            + " [0-8]: ");
            isValidInput = objValidation.isIntegerInRange(userInput, 0, 8);
        }
        int starNumber = Integer.parseInt(userInput);
        team.setStar(starNumber);
    }

    /**
     * Mutator method to set Team A with a new Team A.
     *
     * @param   newTeamA                The new Team A as a Team.
     */
    public void setTeamA(Team newTeamA)
    {
        teamA = newTeamA;
    }

    /**
     * Mutator method to set Team B with a new Team B.
     *
     * @param   newTeamB                The new Team B as a Team.
     */
    public void setTeamB(Team newTeamB)
    {
        teamB = newTeamB;
    }

    /**
     * Mutator method to set Team Possession with a new Team.
     *
     * @param   newTeamPossession       The new Team Possession as a Team.
     */
    public void setTeamPossession(Team newTeamPossession)
    {
        teamPossession = newTeamPossession;
    }

    /**
     * Mutator method to set Previous Team Possession with a new Team.
     *
     * @param   newPrevTeamPossession   The new Previous Team Possession as a Team.
     */
    public void setPrevTeamPossession(Team newPrevTeamPossession)
    {
        prevTeamPossession = newPrevTeamPossession;
    }

    /**
     * A method to start the AFLGame.
     *
     */
    public void startGame()
    {
        int quarter = 0;
        int event = 0;
        int prevScore = 0;

        FileIO fileA = new FileIO("teamA.txt");
        teamA = fileA.getTeam();
        FileIO fileB = new FileIO("teamB.txt");
        teamB = fileB.getTeam();

        System.out.println("Welcome to the Australian Rules Football Simulation");
        System.out.println("===================================================");

        setStar(teamA);
        setStar(teamB);

        for (quarter = 0; quarter < QUARTER; quarter++)
        {
            for (event = 0 ; event < EVENT; event++)
            {

                if (event == 0)
                {
                    System.out.printf("\n*** Quarter #%d ***", quarter+1);
                    System.out.printf("\n#%d:\n", event+1);
                    kickOff();
                }
                else
                {
                    System.out.printf("\n#%d:\n", event+1);
                }

                if (teamPossession.equals(prevTeamPossession) && 
                (teamPossession.getTeamScore() - prevScore == GOAL) && event != 0)
                {
                    kickOff();
                }
                prevTeamPossession = teamPossession;
                prevScore = teamPossession.getTeamScore();

                String movement = teamPossession.playerAction();

                switch (movement) 
                {
                    case "Score Goal":
                        scoreGoal();
                        break;
                    case "Score Behind":
                        scoreBehind();
                        continueGame();
                        break;
                    case "Pass to Forward":
                        passToForward();
                        break;
                    case "Pass to Midfielder":
                        passToMidfield();
                        break;
                    case "Turnover":
                        turnover();
                        break;
                    case "":
                        System.out.println("This player is a reserve.");
                }
                reportPlayer();
                getInjured();

                // Test only
                // int possessionCount = 0;
                // for (Player tmp : teamA.getPlayers())
                // {
                //     if (tmp.isHoldingBall())
                //     {
                //         possessionCount += 1;
                //     }
                // }
                // System.out.printf("Team A: %d player(s) have possession.\n", possessionCount);
                // possessionCount = 0;
                // for (Player tmp : teamB.getPlayers())
                // {
                //     if (tmp.isHoldingBall())
                //     {
                //         possessionCount += 1;
                //     }
                // }
                // System.out.printf("Team B: %d player(s) have possession.\n", possessionCount);
                // End Test Only

                if (prevTeamPossession.getInjuryCount() > prevTeamPossession.getReserveCount())
                {
                    break;
                }
                else if (teamPossession.getInjuryCount() > teamPossession.getReserveCount())
                {
                    break;
                }
            }
            System.out.printf("\nQuarter %d has finished.\n", quarter+1);
            System.out.println("\nQuarter summary:");
            System.out.printf("   %s has %d points.\n", teamA.getTeamName(), teamA.getTeamScore());
            System.out.printf("   %s has %d points.\n\n", teamB.getTeamName(), teamB.getTeamScore());

            if (prevTeamPossession.getInjuryCount() > prevTeamPossession.getReserveCount())
            {
                break;
            }
            else if (teamPossession.getInjuryCount() > teamPossession.getReserveCount())
            {
                break;
            }
        }
        endGame();
        System.out.println();
        System.out.println("Writing output files...");

        FileIO fileAOutput = new FileIO("teamAUpdated.txt");
        fileAOutput.createFile(teamA);
        FileIO fileBOutput = new FileIO("teamBUpdated.txt");
        fileBOutput.createFile(teamB);

        System.out.println("Goodbye");
    }

    /**
     * A method to substitute an injured player.
     *
     * @param injuredTeam   A team with an injured player as a Team.
     * @param position      A position to find a substitution as a String.
     */
    public void substitutePlayer(Team injuredTeam, String position)
    {
        String greenCircle = "\u001B[32m\u25CF\u001B[0m";
        injuredTeam.findSubstitute(position);
        System.out.printf(" comes on as a substitute. %s\n", greenCircle);
    }

    /**
     * A method to swap the team's possession.
     *
     */
    public void swapTeam()
    {
        if (teamPossession.equals(teamA))
        {
            teamPossession = teamB;
        }
        else if (teamPossession.equals(teamB))
        {
            teamPossession = teamA;
        }
    }

    /**
     * Formats the state of the object into a String.
     *
     * @return              The state of the object as a string.
     */
    public String toString()
    {
        return teamA.getTeamName() + " VS " + teamB.getTeamName();
    }

    /**
     * A method to handle the turnover event of the game.
     *
     */
    public void turnover()
    {
        String prompt = "";
        String checkPosition = teamPossession.getPlayerWithBall().getPosition();
        System.out.printf(" lost the ball to ");
        swapTeam();
        if (checkPosition.equalsIgnoreCase("Defender"))
        {
            teamPossession.choosePossession("Forward");
            prompt = "in the offensive half";
        }
        else if (checkPosition.equalsIgnoreCase("Forward"))
        {
            teamPossession.choosePossession("Defender");
            prompt = "in the defensive half";
        }
        else if (checkPosition.equalsIgnoreCase("Midfielder"))
        {
            teamPossession.choosePossession("Midfielder");
            prompt = "in the middle field";
        }
        else
        {
            teamPossession.choosePossession("Reserve");
            prompt = "in the bench";
        }

        System.out.printf(".\n");
        teamPossession.displayPossession();
        System.out.printf(" has the ball %s.\n", prompt);
    }
    
}
