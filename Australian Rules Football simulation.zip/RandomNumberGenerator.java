import java.lang.Math;
import java.util.Random;

/**
 * Class which generates a random number
 *
 * @author Dicky Arnan
 * @version ver1.0.0
 */
public class RandomNumberGenerator
{
    private int randomInt;

    /**
     * Default constructor which creates the object of the class RandomNumberGenerator.
     *
     */
    public RandomNumberGenerator()
    {
        randomInt = 0;
    }

    /**
     * Non-Default constructor which creates the object of the class RandomNumberGenerator.
     *
     * @param newLower   Accepts the lower limit as an Integer.
     * @param newUpper   Accepts the upper limit as an Integer.
     */
    public RandomNumberGenerator(int newLower, int newUpper)
    {
        randomInt = (int)(Math.random() * (newUpper - newLower + 1) + newLower);
    }

    /**
     * Display method to display the status for the object.
     *
     */
    public void display()
    {
        System.out.println(toString());
    }

    /**
     * Accessor method to get the random integer.
     *
     * @return              The random integer as an Integer.
     */
    public int getRandomInt()
    {
        return randomInt;
    }

    /**
     * A method to get a random integer between 1 and 100.
     *
     * @return              A random integer between 1 and 100 as an Integer.
     */
    public int giveRandomInt()
    {
        randomInt = (int)(Math.random() * 100 + 1);
        return randomInt;
    }


    /**
     * A method to get a random integer between lowerLimit(inclusive) and upperLimit(exclusive).                    
     *
     * @param   lowerLimit  A number set as the lower limit as an Integer.
     * @param   upperLimit  A number set as the upper limit as an Integer.
     * @return              A random integer between lowerLimit and upperLimit(exclusive) as an Integer.
     */
    public int giveRandomInt(int lowerLimit, int upperLimit)
    {
        Random random = new Random();
        randomInt = random.nextInt(lowerLimit, upperLimit);
        return randomInt;
    }

    /**
     * Mutator method to set the random integer.
     *
     * @param   newRandom  A new number as an Integer.
     */
    public void setRandomInt(int newRandom)
    {
        randomInt = newRandom;
    }

    /**
     * Formats the state of the object into a String.
     *
     * @return              The state of the object as a string.
     */
    public String toString()
    {
        return "" + randomInt;
    }

}
