import java.util.Scanner;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;


/**
 * Class which stores information of players
 *
 * @author Dicky Arnan
 * @version ver1.0.0
 */
public abstract class Player
{
    private String name;
    private String position;
    private int goal;
    private int behind;
    private int kick;
    private int pass;
    private int reported;
    private boolean holdingBall;
    private boolean injured;
    private boolean reserve;
    private boolean star;
    private static final String[] POSITION = {"Forward", "Midfielder", "Defender", "Reserve"};
    
    /**
     * Default constructor which creates the object of the class Player.
     *
     */ 
    public Player()
    {
        this.name = "PlayerX##";
        this.position = "Unknown";
        this.goal = 0;
        this.behind = 0;
        this.kick = 0;
        this.pass = 0;
        this.reported = 0;
        this.holdingBall = false;
        this.injured = false;
        this.reserve = false;
        this.star = false;
    }

    /**
     * Non-Default constructor which creates the object of the class Player.
     *
     * @param newName     Accepts the player's name as a String.
     * @param newPosition Accepts the player's position as a String.
     * @param newGoal     Accepts the player's goal as an Integer.
     */
    public Player(String newName, String newPosition, int newGoal)
    {   
        Validation validInput = new Validation();
        boolean isValidName = validInput.stringLengthInRange(newName, 1,35);
        boolean isValidPosition = Arrays.asList(POSITION).contains(newPosition);
        if (isValidName)
        {
            name = newName;
        }
        else
        {
            System.out.println("Invalid New Name. " +
                               "Player Name cannot be blank and must start with a letter. \n" +
                               "Player Name set to default: \"PlayerX##\".");
            name = "PlayerX##";
        }

        if (isValidPosition)
        {
            position = newPosition;
        }
        else
        {
            System.out.println("Invalid New Position. " +
                               "Player position must be either Forward, Midfielder, Defender or Reserve. \n" +
                               "Player position set to default: \"Unknown\".");
            position = "Unknown";
        }
        
        if (newGoal >= 0)
        {
            goal = newGoal;
        }
        else
        {
            System.out.println("Invalid New Goal. " +
                               "Player Goal must be greater or equal to 0. \n" +
                               "Player Goal set to default: 0.");
            goal = 0;
        }
        // Other attributes are set to default.
        behind = 0;
        kick = 0;
        pass = 0;
        reported = 0;
        holdingBall = false;
        injured = false;
        reserve = false;
        star = false; 
    }

    /**
     * A method to choose the player's action.
     *
     * @param randomNumber  Accepts a random number to choose player's action as an Integer.
     * @return              A string which contain the information of the action as a String.
     */
    public abstract String action(int randomNumber);

    /**
     * A method to add the player's number of behind by 1.
     *
     */
    public void addBehind()
    {
        behind += 1;
    }

    /**
     * A method to add the player's number of goal by 1.
     *
     */
    public void addGoal()
    {
        goal += 1;
    }

    /**
     * A method to add the player's number of kick by 1.
     *
     */
    public void addKick()
    {
        kick += 1;
    }

    /**
     * A method to add the player's number of pass by 1.
     *
     */
    public void addPass()
    {
        pass += 1;
    }
    
    /**
     * A method to add the player's number of reported times by 1.
     *
     */
    public void addReported()
    {
        reported += 1;
    }

    /**
     * Display method to display the status for the object.
     *
     */
    public void display()
    {
        System.out.println(toString());
    }

    /**
     * Accessor method to get the player's behind score.
     *
     * @return              The player's behind score as an Integer.
     */
    public int getBehind()
    {
        return behind;
    }

    /**
     * Accessor method to get the player's actions chance.
     *
     * @return              The player's actions chance as an Array of Integer.
     */
    public abstract int[] getChance();

    /**
     * Accessor method to get the player's goal score.
     *
     * @return              The player's goal score as an Integer.
     */
    public int getGoal()
    {
        return goal;
    }

    /**
     * A method to get an index for the player's action move.
     *
     * @param   aChance     The player's chance of move as an Array of Integers.
     * @param   aRandom     A random number generated as an Integer.
     * @return              An index for he player's action move as an Integer.
     */
    public int getIndex(int[] aChance, int aRandom)
    {   
        int index = 0;
        for (int i = 0; i < aChance.length; i++)
        {   
            aRandom -= aChance[i];
            if (aRandom <=0)
            {
                index = i;
                break;
            }
        }
        return index;
    }

    /**
     * Accessor method to get the player's number of kick.
     *
     * @return              The player's number of kick as an Integer.
     */
    public int getKick()
    {
        return kick;
    }
    
    /**
     * Accessor method to get the player's name.
     *
     * @return              The player's name as a String.
     */
    public String getName()
    {
        return name;
    }

    /**
     * Accessor method to get the player's number of pass.
     *
     * @return              The player's number of pass as an Integer.
     */
    public int getPass()
    {
        return pass;
    }

    /**
     * A method to get the player's position type.
     *
     * @return              The player's position type as a String.
     */
    public abstract String getPlayerType();

    /**
     * Accessor method to get the player's position.
     *
     * @return              The player's position as a String.
     */
    public String getPosition()
    {
        return position;
    }

    /**
     * Accessor method to get the player's number of report.
     *
     * @return              The player's number of report as an Integer.
     */
    public int getReported()
    {
        return reported;
    }

    /**
     * Accessor method to get the player's status of holding the ball.
     *
     * @return              The player's status of holding the ball as a boolean.
     */
    public boolean isHoldingBall()
    {
        return holdingBall;
    }

    /**
     * Accessor method to get the player's injury status.
     *
     * @return              The player's injury status as a boolean.
     */
    public boolean isInjured()
    {
        return injured;
    }

    /**
     * Accessor method to get the player's reserve status.
     *
     * @return              The player's reserve status as a boolean.
     */
    public boolean isReserve()
    {
        return reserve;
    }

    /**
     * Accessor method to get the player's star status.
     *
     * @return              The player's star status as a boolean.
     */
    public boolean isStar()
    {
        return star;
    }

    /**
     * Mutator method to set the player's behind score.
     *
     * @param   newBehind  The player's behind score as an Integer.
     */
    public void setBehind(int newBehind)
    {   
        if (newBehind >=0)
        {
            behind = newBehind;
        }
        else
        {
            System.out.println("Invalid New Behind. " +
                               "Player Behind must be greater or equal to 0. \n" +
                               "Player Behind set to default: 0.");
            behind = 0;
        }
    }

    /**
     * Mutator method to set the player's actions chance.
     *
     * @param   newChance  The player's new actions chance as an Array of Integer.
     */
    public abstract void setChance(int[] newChance);

    /**
     * Mutator method to set the player's goal score.
     *
     * @param   newGoal  The player's goal score as an Integer.
     */
    public void setGoal(int newGoal)
    {
        if (newGoal >=0)
        {
            goal = newGoal;
        }
        else
        {
            System.out.println("Invalid New Goal. " +
                               "Player Goal must be greater or equal to 0. \n" +
                               "Player Goal set to default: 0.");
            goal = 0;
        }
    }

    /**
     * Mutator method to set the player's status of holding the ball.
     *
     * @param   value  The player's status of holding the ball as a boolean.
     */
    public void setHoldingBall(boolean value)
    {
        holdingBall = value;
    }

    /**
     * Mutator method to set the player's injury status.
     *
     * @param   value  The player's injury status as a boolean.
     */
    public void setInjured(boolean value)
    {
        injured = value;
    }

    /**
     * Mutator method to set the player's number of kick.
     *
     * @param   newKick  The player's number of kick as an Integer.
     */
    public void setKick(int newKick)
    {
        if (newKick >=0)
        {
            kick = newKick;
        }
        else
        {
            System.out.println("Invalid New Kick. " +
                               "Player Kick must be greater or equal to 0. \n" +
                               "Player Kick set to default: 0.");
            kick = 0;
        }
    }

    /**
     * Mutator method to set the player's name.
     *
     * @param   newName  The player's name as a String.
     */
    public void setName(String newName)
    {
        Validation validInput = new Validation();
        boolean isValidName = validInput.stringLengthInRange(newName, 1,35);
        if (isValidName)
        {
            name = newName;
        }
        else
        {
            System.out.println("Invalid New Name. " +
                               "Player Name cannot be blank and must start with a letter. \n" +
                               "Player Name set to default: \"PlayerX##\".");
            name = "PlayerX##";
        }
    }

    /**
     * Mutator method to set the player's number of pass.
     *
     * @param   newPass  The player's number of pass as an Integer.
     */
    public void setPass(int newPass)
    {
        if (newPass >=0)
        {
            pass = newPass;
        }
        else
        {
            System.out.println("Invalid New Pass. " +
                               "Player Pass must be greater or equal to 0. \n" +
                               "Player Pass set to default: 0.");
            pass = 0;
        }
    }

    /**
     * Mutator method to set the player's position.
     *
     * @param   newPosition  The player's position as a String.
     */
    public void setPosition(String newPosition)
    {
        Validation validInput = new Validation();
        boolean isValidPosition = Arrays.asList(POSITION).contains(newPosition);
        if (isValidPosition)
        {
            position = newPosition;
        }
        else
        {
            System.out.println("Invalid New Position. " +
                               "Player position must be either Forward, Midfielder, Defender or Reserve. \n" +
                               "Player position set to default: \"Unknown\".");
            position = "Unknown";
        }
    }

    /**
     * Mutator method to set the player's number of report.
     *
     * @param   newReported  The player's number of report as an Integer.
     */
    public void setReported(int newReported)
    {
        if (newReported >=0)
        {
            reported = newReported;
        }
        else
        {
            System.out.println("Invalid New Reported. " +
                               "Player Reported must be greater or equal to 0. \n" +
                               "Player Reported set to default: 0.");
            reported = 0;
        }
    }

    /**
     * Mutator method to set the player's reserve status.
     *
     * @param   value  The player's reserve status as a boolean.
     */
    public void setReserve(boolean value)
    {
        reserve = value;
    }

    /**
     * Mutator method to set the player's star status.
     *
     * @param   value  The player's star status as a boolean.
     */
    public void setStar(boolean value)
    {
        star = value;
    }
    
    /**
     * A method to set the star player's actions chance.
     *
     */
    public abstract void setStarChance();

    /**
     * Formats the state of the object into a String.
     *
     * @return              The state of the object as a string.
     */
    public String toString()
    {
        return (name + "," + position + "," + goal + "\n");
        
        /** Different Formatting
        // return (name + "," + position + "," + goal + "," + injured + "," + reserve + "\n");
        
        // return ("\nName: " + name + "\nPosition: " + position + "\nGoal(s): " + goal + 
        //         "\nReported: " + reported + " time(s)" +
        //         "\nStar: " + isStar + "\nInjured: " + isInjured + "\n");
        */
    }

}

