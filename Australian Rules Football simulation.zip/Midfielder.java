import java.util.Arrays;

/**
 * Class which stores information about Midfielder player
 *
 * @author Dicky Arnan
 * @version ver1.0.0
 */
public class Midfielder extends Player
{
    private int[] chance;

    /**
     * Default constructor which creates the object of the class Midfielder.
     *
     */
    public Midfielder()
    {
        super();
        setPosition("Midfielder");
        chance = new int[] {5,10,30,30,25};
    }

    /**
     * Non-Default constructor which creates the object of the class Midfielder.
     *
     * @param newName     Accepts the player's name as a String.
     * @param newPosition Accepts the player's position as a String.
     * @param newGoal     Accepts the player's goal as an integer.
     */
    public Midfielder(String newName, String newPosition, int newGoal)
    {
        super(newName, newPosition, newGoal);
        chance = new int[] {5,10,30,30,25};
    }

    /**
     * A method to choose the player's action.
     *
     * @param randomNumber  Accepts a random number to choose player's action as an Integer.
     * @return              A string which contain the information of the action as a String.
     */
    public String action(int randomNumber)
    {
        String move = "";
        int index = getIndex(chance, randomNumber);
        switch (index) 
        {
            case 0:
                move = "Score Goal";
                break;
            case 1:
                move = "Score Behind";
                break;
            case 2:
                move = "Pass to Forward";
                break;
            case 3:
                move = "Pass to Midfielder";
                break;
            case 4:  
                move = "Turnover";
                break;
        }
        return move;
    }

    /**
     * Display method to display the status for the object.
     *
     */
    public void display()
    {
        System.out.println(Arrays.toString(chance));
    }

    /**
     * Accessor method to get the player's actions chance.
     *
     * @return              The player's actions chance as an Array of Integer.
     */
    public int[] getChance()
    {
        return chance;
    }

    /**
     * A method to get the player's position type.
     *
     * @return              The player's position type as a String.
     */
    public String getPlayerType()
    {
        return "Midfielder";
    }

    /**
     * Mutator method to set the player's actions chance.
     *
     * @param   newChance  The player's new actions chance as an Array of integer.
     */
    public void setChance(int[] newChance)
    {
        chance = newChance;
        for (int i = 0; i < newChance.length; i++)
        {
            if (newChance[i] < 0)
            {
                System.out.println("Invalid New Player Chance. " +
                                   "Player Chance must consist of integer greater or equal to 0. \n" +
                                   "Player Chance set to default.");
                chance = new int[] {5,10,30,30,25};
                break; 
            }
        }
    }

    /**
     * A method to set the star player's actions chance.
     *
     */
    public void setStarChance()
    {
        chance = new int[] {10,10,35,35,10};
    }

}
