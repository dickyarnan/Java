import java.util.Scanner;

/**
 * Class which stores information of input
 *
 * @author Dicky Arnan
 * @version ver1.0.0
 */
public class Input
{   
    Scanner console = new Scanner(System.in);

    /**
     * Default constructor which creates the object of the class Input.
     *
     */
    public Input()
    {
        
    }

    /**
     * A method to accept the character input.
     *
     * @param   prompt    A prompt to ask user for input as String.
     * @param   i         An index as integer to get the character in user input.
     * @return            The charater input as a char.
     */
    public char acceptCharInput(String prompt, int i)
    {   
        System.out.println(prompt);
        char charInput = console.nextLine().charAt(i);
        return charInput;
    }

    /**
     * A method to accept the double input.
     *
     * @param   prompt    A prompt to ask user for input as String.
     * @return            The charater input as a double.
     */
    public double acceptDoubleInput(String prompt)
    {
        System.out.println(prompt);
        double doubleInput = console.nextDouble();
        console.nextLine();
        return doubleInput;
    }

    /**
     * A method to accept the integer input.
     *
     * @param   prompt    A prompt to ask user for input as String.
     * @return            The charater input as an integer.
     */
    public int acceptIntegerInput(String prompt)
    {
        System.out.printf(prompt);
        int intInput = console.nextInt();
        console.nextLine();
        return intInput;
    }

    /**
     * A method to accept the String input.
     *
     * @param   prompt    A prompt to ask user for input as String.
     * @return            The charater input as a String.
     */
    public String acceptStringInput(String prompt)
    {
        System.out.printf(prompt);
        String strInput = console.nextLine().trim();
        return strInput;
    }
    
    /**
     * Display method to display the object.
     *
     */
    public void display()
    {
        System.out.println(toString());
    }

    /**
     * Formats the state of the object into a String.
     *
     * @return              The state of the object as a string.
     */
    public String toString()
    {
        Input objInput = new Input();
        return objInput.toString();
    }
}


