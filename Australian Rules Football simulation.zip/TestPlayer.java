import java.util.Scanner;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;


/**
 * Class which test the information of players
 *
 * @author Dicky Arnan
 * @version ver1.0.0
 */
public class TestPlayer
{
    private Player player;

    /**
     * Default constructor which creates the object of the class TestPlayer.
     *
     */
    public TestPlayer()
    {
        player = new Forward();
    }
    
    /**
     * Non-Default constructor which creates the object of the class TestPlayer.
     *
     * @param newPlayer     Accepts a new player as a Player.
     */
    public TestPlayer(Player newPlayer)
    {
        player = newPlayer;
    }

    /**
     * A method to display the grid lines.
     *
     */
    public void displayLine()
    {
        for (int i = 0; i < 83; i++)
        {
            System.out.printf("-");
        }
        System.out.printf("\n");
    }

    /**
     * Method to being the program.
     *
     * @param args          An array of Strings representing command line arguments.
     */
    public static void main(String[] args)
    {
        TestPlayer test = new TestPlayer();
        test.testPlayer();
        // test.testGetMethod();
        // test.testSetMethod();
        // test.testOtherMethod();
    }

    /**
     * A method to test the get methods.
     *
     */
    public void testGetMethod()
    {
        player = new Forward("playerA1", "Forward", 0);

        String name = player.getName();
        System.out.printf("\nname = %s\n", name);

        boolean star = player.isStar();
        System.out.printf("\nstar = %b\n", star);

        System.out.println("\nchance = " + Arrays.toString(player.getChance()));
    }

    /**
     * A method to test the other methods.
     *
     */
    public void testOtherMethod()
    {
        player = new Forward("playerA1", "Forward", 0);
        // player = new Forward("", "", -99);
        System.out.println("\n" + player.toString());
    }

    /**
     * A method to test the Player object.
     *
     */
    public void testPlayer()
    {
        // player = new Forward();
        player = new Forward("playerA1", "Forward", 99);
        // player = new Forward("123ABC", "Back", -100);
        String name = player.getName();
        String position = player.getPosition();
        int goal = player.getGoal();
        int behind = player.getBehind();
        int kick = player.getKick();
        int pass = player.getPass();
        int reported = player.getReported();
        boolean holdingBall = player.isHoldingBall();
        boolean injured = player.isInjured();
        boolean reserve = player.isReserve();
        boolean star = player.isStar();

        System.out.println();
        // System.out.println("Create a Forward Object with the default constructor");
        System.out.println("Create a Forward Object with the non-default constructor with valid field values.");
        // System.out.println("Create a Forward Object with the non-default constructor with invalid field values.");
        
        displayLine();
        System.out.printf("|%-15s |%-15s |%-10s |%-10s |%-10s |%-10s |\n",
                          "Name", "Position", "Goals", "Behinds", "Kicks", "Pass");
        displayLine();
        System.out.printf("|%-15s |%-15s |%-10d |%-10d |%-10d |%-10d |\n",
                          name, position, goal, behind, kick, pass);
        displayLine();
        displayLine();
        System.out.printf("|%-15s |%-15s |%-10s |%-10s |%-10s |%-10s |\n", 
                          "Reported", "Holding Ball", "Injured", "Reserve", "Star", "");
        displayLine();
        System.out.printf("|%-15d |%-15b |%-10b |%-10b |%-10b |%-10s |\n",
                          reported, holdingBall, injured, reserve, star, "");
        displayLine();
    }

    /**
     * A method to test the set methods.
     *
     */
    public void testSetMethod()
    {
        player = new Forward();

        player.setName("PlayerB99");
        // player.setName("");

        String name = player.getName();
        System.out.printf("\nname = %s\n", name);

        player.setGoal(9999);
        // player.setGoal(-1001);

        int goal = player.getGoal();
        System.out.printf("\ngoal = %d\n", goal);

        player.setChance(new int[] {80,10,5,5});
        // player.setChance(new int[] {80,-10,5,-5});
        System.out.println("\nchance = " + Arrays.toString(player.getChance()));
    }
}

