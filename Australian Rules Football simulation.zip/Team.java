import java.util.Scanner;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Random;

/**
 * Class which stores information of teams
 *
 * @author Dicky Arnan
 * @version ver1.0.0
 */
public class Team
{
    private String teamName;
    private ArrayList<Player> players;
    private int teamScore;
    private int injuryCount;
    private int reserveCount;
    private int playerIndex;
    private Player playerWithBall;
    private Player previousPlayer;
    private static RandomNumberGenerator random = new RandomNumberGenerator();

    /**
     * Default constructor which creates the object of the class Team.
     *
     */ 
    public Team()
    {
        teamName = "Team #";
        players = new ArrayList<Player>();
        teamScore = 0;
        injuryCount = 0;
        reserveCount = 0;
        playerIndex = 0;
        playerWithBall = null;
        previousPlayer = null;
        
    }

    /**
     * Non-Default constructor which creates the object of the class Team.
     *
     * @param newTeamName   Accepts the team's name as a String.
     * @param newPlayers    Accepts the team's list of players as an ArrayList.
     */
    public Team(String newTeamName, ArrayList<Player> newPlayers)
    {   
        if (newTeamName != "" && Character.isAlphabetic(newTeamName.charAt(0)))
        {
            teamName = newTeamName;
        }
        else
        {
            System.out.println("Invalid New Team Name. " +
                               "Team Name cannot be blank and must start with a letter. \n" +
                               "Team Name set to default: \"Team #\".");
            teamName = "Team #";
        }
        players = newPlayers;
        teamScore = 0;
        injuryCount = 0;
        reserveCount = 0;
        for (Player player : players)
        {
            if (player.isReserve())
            {
                reserveCount++;
            }
        }
        playerIndex = 0;
        playerWithBall = null;
        previousPlayer = null;
        
    }

    /**
     * A method to add the team's injury count by 1.
     *
     */
    public void addInjuryCount()
    {
        injuryCount += 1;
    }


    /**
     * A method to add the team's score.
     *
     * @param aScore    A score to be added to the team's score as an Integer.
     */
    public void addTeamScore(int aScore)
    {
        teamScore += aScore;
    }

    /**
     * A method to choose a player from the team's list of players.
     *
     * @param position    A position to find the player on the team as a String.
     */
    public void choosePossession(String position)
    {   
        playerIndex = random.giveRandomInt(0,players.size());
        playerWithBall = players.get(playerIndex);
        
        while (!playerWithBall.getPosition().equalsIgnoreCase(position) || 
                playerWithBall.isInjured() || 
                playerWithBall.isHoldingBall())
        {
            playerIndex = random.giveRandomInt(0,players.size());
            playerWithBall = players.get(playerIndex);
        }
        displayPossession();

        try
        {
            previousPlayer.setHoldingBall(false);
        }
        catch (Exception e)
        {
            previousPlayer = new Reserve();
        }

        playerWithBall.setHoldingBall(true);
        
        /** For Testing Only
        // for(Player temp : players)
        // {
        //     if (temp.isHoldingBall())
        //     {
        //         System.out.println("\n---\n" +temp + "---");
        //     }
        // }
        */
    }

    /**
     * A method to choose a player from the team to be reported.
     *
     */
    public void chooseReported()
    {
        playerIndex = random.giveRandomInt(0,players.size());
        Player reportedPlayer = players.get(playerIndex);
        while (reportedPlayer.getPosition().equalsIgnoreCase("Reserve") || 
               reportedPlayer.isInjured())
        {
            playerIndex = random.giveRandomInt(0,players.size());
            reportedPlayer = players.get(playerIndex);
        }
        displayPlayer(reportedPlayer);
        reportedPlayer.addReported();
    }

    /**
     * A method to create a list of players for the team.
     *
     * @param playerDetails    An Array of String containing players detail to be added as an ArrayList.
     */
    public void createPlayers(ArrayList<String[]> playerDetails)
    {
        for (String[] line : playerDetails)
        {
            String name = line[0];
            String position = line[1];
            int goal = Integer.parseInt(line[2]);  // parseInt

            if (position.equalsIgnoreCase("Forward"))
            {
                Player player = new Forward(name, position, goal);
                players.add(player);
            }
            else if (position.equalsIgnoreCase("Midfielder"))
            {
                Player player = new Midfielder(name, position, goal);
                players.add(player);
            }
            else if (position.equalsIgnoreCase("Defender"))
            {
                Player player = new Defender(name, position, goal);
                players.add(player);
            }
            else if (position.equalsIgnoreCase("Reserve"))
            {
                Player player = new Reserve(name, position, goal);
                players.add(player);
                player.setReserve(true);
                reserveCount += 1;
            }
            else
            {
                Player player = new Reserve();
            }
        }
    }

    /**
     * Display method to display the status for the object.
     *
     */
    public void display()
    {
        System.out.println(toString());
        for (Player player : players)
        {
            System.out.println(player);
        }
    }

    /**
     * Display method to display the status of a choosen player.
     *
     * @param aPlayer   A player to be displayed as a Player.
     */
    public void displayPlayer(Player aPlayer)
    {
        System.out.printf("%s (%s, %s)", 
                        aPlayer.getName(), 
                        aPlayer.getPosition(), 
                        getTeamName());
    }

    /**
     * Display method to display the status of the player holding the ball.
     *
     */
    public void displayPossession()
    {
        System.out.printf("%s (%s, %s)", 
                        playerWithBall.getName(), 
                        playerWithBall.getPosition(), 
                        getTeamName());
    }

    /**
     * A method to find a substitute player based on the position.
     *
     * @param position    A position to find the player on the team as a String.
     */
    public void findSubstitute(String position)
    {
        playerIndex = random.giveRandomInt(0,players.size());
        Player substitutePlayer = players.get(playerIndex);

        while (substitutePlayer.isInjured() || 
              !substitutePlayer.getPosition().equalsIgnoreCase("Reserve"))
        {
            playerIndex = random.giveRandomInt(0,players.size());
            substitutePlayer = players.get(playerIndex);
        }

        Player tempPlayer = substitutePlayer;
        if (position.equalsIgnoreCase("Forward"))
        {
            tempPlayer = new Forward();  
        }
        else if (position.equalsIgnoreCase("Midfielder"))
        {
            tempPlayer = new Midfielder();  
        }
        else if (position.equalsIgnoreCase("Defender"))
        {
            tempPlayer = new Defender();  
        }
        else
        {
            tempPlayer = new Reserve();
        }

        if (substitutePlayer.isStar())
        {
            tempPlayer.setStarChance();
        }   

        substitutePlayer.setPosition(tempPlayer.getPlayerType());
        substitutePlayer.setReserve(false);
        substitutePlayer.setChance(tempPlayer.getChance());

        if (playerWithBall.isInjured())
        {
            playerWithBall = substitutePlayer;
        }

        System.out.printf("Found a substitution: ");
        displayPlayer(substitutePlayer);
    }

    /**
     * A method to choose 1 injured player and get the position of that player.
     *
     * @return          The position of an injured player as a String.
     */
    public String getInjuredPlayer()
    {
        displayPlayer(playerWithBall);
        playerWithBall.setInjured(true);
        playerWithBall.setHoldingBall(false);
        return playerWithBall.getPosition();
    }
    
    /**
     * Accessor method to get the team's injury count.
     *
     * @return              The team's injury count as an Integer.
     */
    public int getInjuryCount()
    {
        return injuryCount;
    }

    /**
     * Accessor method to get the list of players.
     *
     * @return              The team's list of players as an ArrayList.
     */
    public ArrayList<Player> getPlayers()
    {
        return players;
    }

    /**
     * A method to get the player of the team.
     *
     * @param   i           The index of the player on the list as an Integer.
     * @return              The team's player as a Player.
     */
    public Player getPlayer(int i)
    {
        return players.get(i);
    }

    /**
     * Accessor method to get the team's player index.
     *
     * @return              The team's player index as an Integer.
     */
    public int getPlayerIndex()
    {
        return playerIndex;
    }

    /**
     * Accessor method to get the player holding the ball.
     *
     * @return              The player's holding the ball as a Player.
     */
    public Player getPlayerWithBall()
    {
        return playerWithBall;
    }

    /**
     * Accessor method to get the previous player holding the ball.
     *
     * @return              The previous player's holding the ball as a Player.
     */
    public Player getPreviousPlayer()
    {
        return previousPlayer;
    }

    /**
     * Accessor method to get the team's reserve count.
     *
     * @return              The team's reserve count as an Integer.
     */
    public int getReserveCount()
    {
        return reserveCount;
    }

    /**
     * Accessor method to get the team name.
     *
     * @return              The team's name as a String.
     */
    public String getTeamName()
    {
        return teamName;
    }

    /**
     * Accessor method to get the team score.
     *
     * @return              The team's score as an Integer.
     */
    public int getTeamScore()
    {
        return teamScore;
    }

    /**
     * A method to hanlde the player's action.
     *
     * @return              The player's action as a String.
     */
    public String playerAction()
    {
        previousPlayer = playerWithBall;
        displayPossession();
        int randomAction = random.giveRandomInt();
        String movement = playerWithBall.action(randomAction);
        switch (movement) 
        {
            case "Score Goal":
                playerWithBall.addGoal();
                break;
            case "Score Behind":
                playerWithBall.addBehind();
                break;
            case "Pass to Forward":
                playerWithBall.addPass();
                break;
            case "Pass to Midfielder":
                playerWithBall.addPass();
                break;
            case "Turnover":
                playerWithBall.setHoldingBall(false);
                break;
            case "":
                System.out.println("This player was a reserve.");
        }
        playerWithBall.addKick();
        return movement;
    }

    /**
     * A method to select a player to be set as injured if team possession does not change.
     *
     * @return              The injured player's position as a String.
     */
    public String selectInjuredPlayer()
    {   
        int chance = random.giveRandomInt(0,2);
        if (chance == 0)
        {
            displayPlayer(previousPlayer);
            previousPlayer.setInjured(true);
            previousPlayer.setHoldingBall(false);
            return previousPlayer.getPosition();
        }
        else 
        {
            displayPlayer(playerWithBall);
            playerWithBall.setInjured(true);
            return playerWithBall.getPosition();
        }
    }

    /**
     * Mutator method to set the team's injury count.
     *
     * @param   newCount  The team's number of injury count as an Integer.
     */
    public void setInjuryCount(int newCount)
    {
        if (newCount >=0)
        {
            injuryCount = newCount;
        }
        else
        {
            System.out.println("Invalid Injury Count. " +
                               "Team Injury Count must be greater or equal to 0. \n" +
                               "Team Injury Count set to default: 0.");
            injuryCount = 0;
        }
    }

    /**
     * Mutator method to set the team's list of players.
     *
     * @param   newPlayers  The list of players as an ArrayList of Player.
     */
    public void setPlayers(ArrayList<Player> newPlayers)
    {
        players = newPlayers;
    }

    /**
     * Mutator method to set the team's reserve count.
     *
     * @param   newIndex  The team's player index as an Integer.
     */
    public void setPlayerIndex(int newIndex)
    {
        if (newIndex >=0)
        {
            playerIndex = newIndex;
        }
        else
        {
            System.out.println("Invalid New Index. " +
                               "Team Player Index must be greater or equal to 0. \n" +
                               "Team Player Index set to default: 0.");
            playerIndex = 0;
        }
    }

    /**
     * Mutator method to set the team's player holding the ball.
     *
     * @param   newPlayerWithBall  The team's player holding the ball as a Player.
     */
    public void setPlayerWithBall(Player newPlayerWithBall)
    {
        playerWithBall = newPlayerWithBall;
    }

    /**
     * Mutator method to set the team's previous player holding the ball.
     *
     * @param   newPreviousPlayer  The team's previous player holding the ball as a Player.
     */
    public void setPreviousPlayer(Player newPreviousPlayer)
    {
        previousPlayer = newPreviousPlayer;
    }

    /**
     * Mutator method to set the team's reserve count.
     *
     * @param   newCount  The team's number of reserve count as an Integer.
     */
    public void setReserveCount(int newCount)
    {
        if (newCount >=0)
        {
            reserveCount = newCount;
        }
        else
        {
            System.out.println("Invalid Reserve Count. " +
                               "Team Reserve Count must be greater or equal to 0. \n" +
                               "Team Reserve Count set to default: 0.");
            reserveCount = 0;
        }
        
    }

    /**
     * A method to set the team's star players.
     *
     * @param   starNumber  The number of players that will be set as star players as an Integer.
     */
    public void setStar(int starNumber)
    {
        if (starNumber < 0)
        {
            starNumber = 0;
        }
        int i = 0;
        while (i < starNumber)
        {  
            // Generate a random index number based on the size of the ArrayList
            int randomIndex = random.giveRandomInt(0, players.size());
            Player player = players.get(randomIndex);
            
            if (player.isStar() == false)
            {
                player.setStar(true);
                player.setStarChance();
                i++;
            }
            else
            {
                continue;
            }
        }
    }

    /**
     * Mutator method to set the team's name.
     *
     * @param   newTeamName  The team's new name as a String.
     */
    public void setTeamName(String newTeamName)
    {
        if (newTeamName != "" && Character.isAlphabetic(newTeamName.charAt(0)))
        {
            teamName = newTeamName;
        }
        else
        {
            System.out.println("Invalid New Team Name. " +
                               "Team Name cannot be blank and must start with a letter. \n" +
                               "Team Name set to default: \"Team #\".");
            teamName = "Team #";
        }
    }

    /**
     * Mutator method to set the team's score.
     *
     * @param   newScore  The team's new score as an Integer.
     */
    public void setTeamScore(int newScore)
    {
        if (newScore >=0)
        {
            teamScore = newScore;
        }
        else
        {
            System.out.println("Invalid New Score. " +
                               "Team Score must be greater or equal to 0. \n" +
                               "Team Score set to default: 0.");
            teamScore = 0;
        }
    }

    /**
     * Formats the state of the object into a String.
     *
     * @return              The state of the object as a string.
     */
    public String toString()
    {
        return teamName + ", Score: " + teamScore;
    } 

}

