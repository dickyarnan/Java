import java.util.Scanner;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;

/**
 * Class which handles file reading and writing
 *
 * @author Dicky Arnan
 * @version ver1.0.0
 */
public class FileIO
{
    private String fileName;
 
    /**
     * Default constructor which creates the object of the class FileIO.
     *
     */
    public FileIO()
    {
        fileName = "fileName.txt";
    }

    /**
     * Non-Default constructor which creates the object of the class Player.
     *
     * @param newFileName   Accepts the file name.
     */
    public FileIO(String newFileName)
    {
        if (newFileName != "" && Character.isAlphabetic(newFileName.charAt(0)))
        {
            fileName = newFileName;
        }
        else
        {
            System.out.println("Invalid New File Name. " +
                               "File Name cannot be blank. \n" +
                               "File Name set to default: \"fileName.txt\".");
            fileName = "fileName.txt";
        }
    }

    /**
     * A method to create and write a file based on the Team object
     *
     * @param   team     The Team object which contains Player objects. 
     */
    public void createFile(Team team)
    {
        try
        {   
            FileWriter writer = new FileWriter(fileName);
            try
            {
                writer.append(team.getTeamName() + "\n");
                for (Player player : team.getPlayers())
                    writer.append(player.toString());
            }
            finally
            {
                try
                {
                    writer.close();
                }
                catch (Exception e)
                {
                    System.out.println("Error in closing file! Exiting...");
                }
            }
        }
        catch(Exception e)
        {
            System.out.println("Error in writing file! Exiting");
        }
    }

    /**
     * Display method to display the status for the object.
     *
     */
    public void display()
    {
        System.out.println(toString());
    }

    /**
     * Accessor method to get the file name.
     *
     * @return              The file name as a String.
     */
    public String getFileName()
    {
        return fileName;
    }

    /**
     * A method to get a Team object by reading a file with details about a team.
     *
     * @return               The Team object created from reading the file.
     */
    public Team getTeam()
    {
        String teamName = "";
        ArrayList<Player> players = new ArrayList<Player>();
        ArrayList<String[]> contents = new ArrayList<String[]>();
        
        try
        {
            Scanner console = new Scanner(System.in);
            FileReader reader = new FileReader(fileName);
            try
            {
                Scanner fileInput = new Scanner(reader);
                int counter = 0;
                while (fileInput.hasNextLine())
                {
                    String[] lineContents = fileInput.nextLine().split(",");
                    try
                    {
                        if (counter == 0)
                        {
                            teamName = lineContents[0];
                        }
                        else
                        {
                            contents.add(lineContents);
                        }
                        
                        counter ++;
                    }
                    catch (Exception e)
                    {
                        System.out.println("Error in iterating the file! Exiting...");
                    }
                }
            }
            finally
            {
                try
                {
                    reader.close();
                }
                catch (Exception e)
                {
                    System.out.println("Error in closing the file! Exiting...");
                }
            }
        }
        catch (Exception e)
        {
            System.out.println("Error in reading the file! Exiting...");
        }

        Team team = new Team();
        team.setTeamName(teamName);
        team.createPlayers(contents);
        return team;
    }

    /**
     * Mutator method to set the file name.
     *
     * @param   newFileName  The file name as a String.
     */
    public void setFileName(String newFileName)
    {
        if (newFileName != "" && Character.isAlphabetic(newFileName.charAt(0)))
        {
            fileName = newFileName;
        }
        else
        {
            System.out.println("Invalid New File Name. " +
                               "File Name cannot be blank. \n" +
                               "File Name set to default: \"fileName.txt\".");
            fileName = "fileName.txt";
        }
    }

    /**
     * Formats the state of the object into a String.
     *
     * @return              The state of the object as a string.
     */
    public String toString()
    {
        return fileName;
    }

}

