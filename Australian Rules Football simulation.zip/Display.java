/**
 * Class which stores information of Display
 *
 * @author Dicky Arnan
 * @version ver1.0.0
 */
public class Display
{
    /**
     * Default constructor which creates the object of the class Display.
     *
     */
    public Display()
    {

    }

    /**
     * A method to display the game result of 2 teams.
     *
     * @param   teamA     A team choosen as Team A as Team object.
     * @param   teamB     A team choosen as Team B as Team object.
     */
    public void displayGameResult(Team teamA, Team teamB)
    {
        Team teamPossession = new Team();
        System.out.println("Game Result");
        System.out.println("===========");
        if (teamA.getTeamScore() > teamB.getTeamScore())
        {
            teamPossession = teamA;
        }
        else if (teamB.getTeamScore() > teamA.getTeamScore())
        {
            teamPossession = teamB;
        }
        else
        {
            System.out.println("The game is a draw!");
            return;
        }

        if (teamA.getInjuryCount() > teamA.getReserveCount())
        {
            teamPossession = teamB;
        }
        else if (teamB.getInjuryCount() > teamB.getReserveCount())
        {
            teamPossession = teamA;
        }
        System.out.printf("%s has won the game with %d points!\n", 
                          teamPossession.getTeamName(), teamPossession.getTeamScore());
    
    }

    /**
     * A method to display the list of injured players of 2 teams.
     *
     * @param   teamA     A team choosen as Team A as Team object.
     * @param   teamB     A team choosen as Team B as Team object.
     */
    public void displayInjured(Team teamA, Team teamB)
    {
        System.out.println();
        System.out.println("Injured Players");
        System.out.println("===============");

        System.out.printf("Team: %s\n", teamA.getTeamName());
        for (Player player : teamA.getPlayers())
        {
            if (player.isInjured())
            {
                System.out.printf("      %s (%s)\n", 
                          player.getName(), player.getPosition());
            }
        }

        System.out.printf("Team: %s\n", teamB.getTeamName());
        for (Player player : teamB.getPlayers())
        {
            if (player.isInjured())
            {
                System.out.printf("      %s (%s)\n", 
                          player.getName(), player.getPosition());
            }
        }
    }
    
    /**
     * A method to display the reported players of 2 teams.
     *
     * @param   teamA     A team choosen as Team A as Team object.
     * @param   teamB     A team choosen as Team B as Team object.
     */
    public void displayReported(Team teamA, Team teamB)
    {
        System.out.println();
        System.out.println("Reported Players");
        System.out.println("================");

        System.out.printf("Team: %s\n", teamA.getTeamName());
        for (Player player : teamA.getPlayers())
        {
            if (player.getReported() > 0)
            {
                System.out.printf("      %s (%s)\n", 
                                  player.getName(), player.getPosition());
            }
        }

        System.out.printf("Team: %s\n", teamB.getTeamName());
        for (Player player : teamB.getPlayers())
        {
            if (player.getReported() > 0)
            {
                System.out.printf("      %s (%s)\n", 
                                  player.getName(), player.getPosition());
            }
        }
    }

    /**
     * A method to display the statistics of a team.
     *
     * @param   team     A team choosen as Team object.
     */
    public void displayStatistic(Team team)
    {
        int totalGoal = 0;
        int totalBehind = 0;
        int mostKick = 0;
        int mostGoal = 0;

        System.out.printf("\n%s\n", team.getTeamName());
        for (Player player : team.getPlayers())
        {
            totalGoal += player.getGoal();
            totalBehind += player.getBehind();
            if (player.getKick() > mostKick)
            {
                mostKick = player.getKick();
            }
            if (player.getGoal() > mostGoal)
            {
                mostGoal = player.getGoal();
            }
        }
        System.out.printf("   Total goals: %d\n", totalGoal);
        System.out.printf("   Total behinds: %d\n", totalBehind);
        System.out.printf("   Total score: %d\n", team.getTeamScore());
        
        System.out.printf("   Who has the greatest number of kicks?\n");
        for (Player player : team.getPlayers())
        {
            if (player.getKick() == mostKick)
            {
                System.out.printf("      %s kicked the ball %d times.\n", 
                                  player.getName(), mostKick);
            }
        }
        System.out.printf("   Who kicked the most goals?\n");
        for (Player player : team.getPlayers())
        {
            if (player.getGoal() == mostGoal)
            {
                System.out.printf("      %s kicked %d goals.\n", 
                                  player.getName(), mostGoal);
            }
        
        }
        
        System.out.println("Individual Statistics:");
        System.out.printf("   %-12s %-8s %-7s %-10s %-7s %-10s %-40s  \n",
        "Name", "Kicks", "Goals", "Behinds", "Pass", "Percent", "Position");
        for (Player player : team.getPlayers())
        {
            String name = player.getName();
            if (player.isStar())
            {
                name += "*";
            }

            double percent = 0.00;
            if (player.getKick() != 0)
            {
                percent = (player.getGoal() + player.getBehind() + 
                player.getPass()) * 100 / (double) player.getKick();
            }

            String position = player.getPosition();
            if (player.isInjured())
            {
                position += " (Injured)";
                if (player.isReserve() || player.getPlayerType().equalsIgnoreCase("Reserve"))
                {
                    position += " (Reserve)";
                }
            }
            System.out.printf("   %-14s %3d %8d %9d %7d %9.2f%%    %-40s  \n",
                               name, player.getKick(), player.getGoal(), 
                               player.getBehind(), player.getPass(), percent, position);
        }
    }

    /**
     * Formats the state of the object into a String.
     *
     * @return          The state of the object as a string.
     */
    public String toString()
    {
        return "";
    }
}
