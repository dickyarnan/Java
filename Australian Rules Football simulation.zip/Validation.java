import java.util.Scanner;

/**
 * Class which validate information from players
 *
 * @author Dicky Arnan
 * @version ver1.0.0
 */
public class Validation
{

    /**
     * Default constructor which creates the object of the class Validation.
     *
     */
    public Validation()
    {
        
    }

    /**
     * A method to check if the input is blank.
     *
     * @param   inputString     The user input as String.
     * @return                  True if the input is blank.
     */
    public boolean isBlank(String inputString)
    {

        if(inputString != null && inputString.trim().length() == 0)
        {
            return true;
        }
        return false;
    }

    /**
     * A method to check if the input is character numeric.
     *
     * @param       c       The user input as character.
     * @return              True if the input is a character numeric.
     */
    public boolean isCharacterNumeric(char c)
    {
        if(Character.isDigit(c))
            return true;
        return false;
    }

    /**
     * A method to check if the length of the input String is in range.
     *
     * @param   inputString     The user input as String.
     * @param   minLength       The minimum length of the String as integer.
     * @param   maxLength       The maximum length of the String as integer.
     * @return                  True if the length of the input is in range.
     */
    public boolean stringLengthInRange(String inputString, int minLength, int maxLength)
    {
        if(inputString != "" && Character.isAlphabetic(inputString.charAt(0)) 
                             && inputString.length() >= minLength 
                             && inputString.length() <= maxLength)
        {
            return true;
        }
        return false;
    }

    /**
     * A method to check if the input String is an Integer.
     *
     * @param   inputString     The user input as String.
     * @return                  True if the input is an Integer.
     */
    public boolean isInteger(String inputString)
    {
        if (isBlank(inputString))
        {
            System.out.println("Error: " + "Input cannot be blank");
            return false;
        }

        try 
        {
            Integer.parseInt(inputString);
            return true;
        }
        catch( Exception e ) 
        {
            System.out.println("Error: " + "\"" + inputString.trim() + "\"" + " is not a valid input.");
            return false;
        }
    }

    /**
     * A method to check if the input number is in range.
     *
     * @param   inputString     The user input as String.
     * @param   minNumber       The minimum number accepted as integer.
     * @param   maxNumber       The maximum number accepted as integer.
     * @return                  True if the length of the input is in range.
     */
    public boolean isIntegerInRange(String inputString, int minNumber, int maxNumber)
    {
        boolean isValidInput = isInteger(inputString);

        if (isValidInput)
        {
            int number = Integer.parseInt(inputString);
            if (number >= minNumber && number <= maxNumber)      
            {
                return true;
            }
            else
            {
                System.out.println("Error: Number not in range: 0 to 8");
                return false;
            }
        }
        else
        {
            return false;
        }

    }
    
    /**
     * Formats the state of the object into a String.
     *
     * @return              The state of the object as a string.
     */
    public String toString()
    {
        return "";
    }
}
